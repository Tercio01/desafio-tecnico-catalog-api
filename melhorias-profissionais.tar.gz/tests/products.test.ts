import request from 'supertest';
import express from 'express';
import productRoutes from '../src/routes/productRoutes';
import authRoutes from '../src/routes/authRoutes';

// Criar app de teste
const app = express();
app.use(express.json());
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);

describe('Products API', () => {
  let adminToken: string;
  let userToken: string;
  let productId: string;

  beforeEach(async () => {
    // Criar usuário admin
    const adminRes = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Admin User',
        email: 'admin@test.com',
        password: 'admin123',
        role: 'admin',
      });
    adminToken = adminRes.body.token;

    // Criar usuário comum
    const userRes = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Regular User',
        email: 'user@test.com',
        password: 'user123',
        role: 'user',
      });
    userToken = userRes.body.token;
  });

  describe('POST /api/products', () => {
    it('should create product with admin token', async () => {
      const productData = {
        name: 'Test Product',
        description: 'Test Description',
        price: 99.99,
        category: 'electronics',
        sku: 'TEST-001',
        stock: 10,
      };

      const response = await request(app)
        .post('/api/products')
        .set('Authorization', `Bearer ${adminToken}`)
        .send(productData);

      expect(response.status).toBe(201);
      expect(response.body.success).toBe(true);
      expect(response.body.data).toHaveProperty('name', productData.name);
      expect(response.body.data).toHaveProperty('_id');
      
      productId = response.body.data._id;
    });

    it('should not create product without admin role', async () => {
      const productData = {
        name: 'Test Product',
        description: 'Test Description',
        price: 99.99,
        category: 'electronics',
        sku: 'TEST-002',
        stock: 10,
      };

      const response = await request(app)
        .post('/api/products')
        .set('Authorization', `Bearer ${userToken}`)
        .send(productData);

      expect(response.status).toBe(403);
      expect(response.body.success).toBe(false);
    });

    it('should not create product without authentication', async () => {
      const productData = {
        name: 'Test Product',
        description: 'Test Description',
        price: 99.99,
        category: 'electronics',
        sku: 'TEST-003',
        stock: 10,
      };

      const response = await request(app)
        .post('/api/products')
        .send(productData);

      expect(response.status).toBe(401);
    });
  });

  describe('GET /api/products', () => {
    beforeEach(async () => {
      // Criar alguns produtos para teste
      await request(app)
        .post('/api/products')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          name: 'Product 1',
          description: 'Description 1',
          price: 100,
          category: 'electronics',
          sku: 'PROD-001',
          stock: 5,
        });

      await request(app)
        .post('/api/products')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          name: 'Product 2',
          description: 'Description 2',
          price: 200,
          category: 'books',
          sku: 'PROD-002',
          stock: 10,
        });
    });

    it('should list all products without authentication', async () => {
      const response = await request(app).get('/api/products');

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data).toBeInstanceOf(Array);
      expect(response.body.data.length).toBeGreaterThan(0);
    });

    it('should filter products by category', async () => {
      const response = await request(app)
        .get('/api/products')
        .query({ category: 'electronics' });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.every((p: any) => p.category === 'electronics')).toBe(true);
    });

    it('should filter products by price range', async () => {
      const response = await request(app)
        .get('/api/products')
        .query({ minPrice: 50, maxPrice: 150 });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.every((p: any) => p.price >= 50 && p.price <= 150)).toBe(true);
    });
  });

  describe('GET /api/products/:id', () => {
    beforeEach(async () => {
      const res = await request(app)
        .post('/api/products')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          name: 'Single Product',
          description: 'Description',
          price: 150,
          category: 'electronics',
          sku: 'SINGLE-001',
          stock: 3,
        });
      productId = res.body.data._id;
    });

    it('should get product by id', async () => {
      const response = await request(app).get(`/api/products/${productId}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data).toHaveProperty('_id', productId);
    });

    it('should return 404 for non-existent product', async () => {
      const fakeId = '507f1f77bcf86cd799439011';
      const response = await request(app).get(`/api/products/${fakeId}`);

      expect(response.status).toBe(404);
      expect(response.body.success).toBe(false);
    });
  });

  describe('PUT /api/products/:id', () => {
    beforeEach(async () => {
      const res = await request(app)
        .post('/api/products')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          name: 'Update Product',
          description: 'Description',
          price: 100,
          category: 'electronics',
          sku: 'UPDATE-001',
          stock: 5,
        });
      productId = res.body.data._id;
    });

    it('should update product with admin token', async () => {
      const updateData = {
        price: 120,
        stock: 8,
      };

      const response = await request(app)
        .put(`/api/products/${productId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send(updateData);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data).toHaveProperty('price', 120);
      expect(response.body.data).toHaveProperty('stock', 8);
    });

    it('should not update product without admin role', async () => {
      const response = await request(app)
        .put(`/api/products/${productId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ price: 120 });

      expect(response.status).toBe(403);
    });
  });

  describe('DELETE /api/products/:id', () => {
    beforeEach(async () => {
      const res = await request(app)
        .post('/api/products')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          name: 'Delete Product',
          description: 'Description',
          price: 100,
          category: 'electronics',
          sku: 'DELETE-001',
          stock: 5,
        });
      productId = res.body.data._id;
    });

    it('should delete product with admin token', async () => {
      const response = await request(app)
        .delete(`/api/products/${productId}`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);

      // Verificar se foi deletado
      const getResponse = await request(app).get(`/api/products/${productId}`);
      expect(getResponse.status).toBe(404);
    });

    it('should not delete product without admin role', async () => {
      const response = await request(app)
        .delete(`/api/products/${productId}`)
        .set('Authorization', `Bearer ${userToken}`);

      expect(response.status).toBe(403);
    });
  });
});
