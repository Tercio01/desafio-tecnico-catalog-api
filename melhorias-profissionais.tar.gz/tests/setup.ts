import mongoose from 'mongoose';
import { MongoMemoryServer } from 'mongodb-memory-server';

let mongoServer: MongoMemoryServer;

// Setup antes de todos os testes
beforeAll(async () => {
  // Criar instância do MongoDB em memória
  mongoServer = await MongoMemoryServer.create();
  const mongoUri = mongoServer.getUri();
  
  // Conectar ao MongoDB de teste
  await mongoose.connect(mongoUri);
});

// Limpar dados entre os testes
afterEach(async () => {
  const collections = mongoose.connection.collections;
  for (const key in collections) {
    await collections[key].deleteMany({});
  }
});

// Cleanup após todos os testes
afterAll(async () => {
  await mongoose.disconnect();
  await mongoServer.stop();
});
